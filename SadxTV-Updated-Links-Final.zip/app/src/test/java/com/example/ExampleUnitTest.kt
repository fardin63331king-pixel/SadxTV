package com.example

import com.example.data.model.ChannelDataUtils
import com.example.data.model.TvChannel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testCategoryNormalization() {
        assertEquals("Sports", ChannelDataUtils.normalizeCategory("SPORTS"))
        assertEquals("Sports", ChannelDataUtils.normalizeCategory("Sky Sports HD"))
        assertEquals("News", ChannelDataUtils.normalizeCategory("News channel"))
        assertEquals("Kids", ChannelDataUtils.normalizeCategory("𝐊𝐢𝐝𝐬"))
        assertEquals("Movies", ChannelDataUtils.normalizeCategory("ENGLISH MOVIES"))
        assertEquals("Bengali", ChannelDataUtils.normalizeCategory("ইন্ডিয়া বাংলা চ্যানেল"))
        assertEquals("Hindi", ChannelDataUtils.normalizeCategory("Indian Hindi"))
        assertEquals("Islamic", ChannelDataUtils.normalizeCategory("𝗜𝘀𝗹𝗮𝗺𝗶𝗰"))
        assertEquals("Series", ChannelDataUtils.normalizeCategory("BACHELOR POINT"))
    }

    @Test
    fun testInitialsGeneration() {
        val ch1 = TvChannel(
            id = "1",
            name = "Zee Bangla",
            icon = "",
            streamUrl = "http://example.com/stream1.m3u8",
            category = "Bengali",
            language = "Bengali",
            description = "Desc",
            currentProgram = "Prog",
            upcomingPrograms = emptyList()
        )
        assertEquals("ZB", ch1.initials)

        val ch2 = TvChannel(
            id = "2",
            name = "BTV",
            icon = "",
            streamUrl = "http://example.com/stream2.m3u8",
            category = "General",
            language = "Bengali",
            description = "Desc",
            currentProgram = "Prog",
            upcomingPrograms = emptyList()
        )
        assertEquals("BTV", ch2.initials)
        assertNotNull(ch2.avatarColor)
    }
}
