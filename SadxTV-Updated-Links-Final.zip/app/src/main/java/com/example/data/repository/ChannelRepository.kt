package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.model.ChannelDataUtils
import com.example.data.model.TvChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ChannelRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ric_tv_prefs", Context.MODE_PRIVATE)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val _favoritesFlow = MutableStateFlow<Set<String>>(emptySet())
    val favoritesFlow: StateFlow<Set<String>> = _favoritesFlow.asStateFlow()

    private val _historyFlow = MutableStateFlow<List<String>>(emptyList())
    val historyFlow: StateFlow<List<String>> = _historyFlow.asStateFlow()

    private val _playbackSpeedFlow = MutableStateFlow(1.0f)
    val playbackSpeedFlow: StateFlow<Float> = _playbackSpeedFlow.asStateFlow()

    private val _subtitlesFlow = MutableStateFlow(false)
    val subtitlesFlow: StateFlow<Boolean> = _subtitlesFlow.asStateFlow()

    init {
        loadPreferences()
    }

    private fun loadPreferences() {
        val favs = prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
        _favoritesFlow.value = favs.toSet()

        val histJson = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        try {
            val arr = JSONArray(histJson)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
            _historyFlow.value = list
        } catch (e: Exception) {
            _historyFlow.value = emptyList()
        }

        _playbackSpeedFlow.value = prefs.getFloat(KEY_PLAYBACK_SPEED, 1.0f)
        _subtitlesFlow.value = prefs.getBoolean(KEY_SUBTITLES, false)
    }

    suspend fun fetchChannels(): Result<List<TvChannel>> = withContext(Dispatchers.IO) {
        val url = "https://go-live-tv-ad864-default-rtdb.firebaseio.com/servers.json"
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "RIC-TV-Android/1.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP error: ${response.code}"))
            }

            val body = response.body?.string() ?: return@withContext Result.failure(Exception("Empty response body"))
            val parsedChannels = parseServersJson(body)

            if (parsedChannels.isEmpty()) {
                return@withContext Result.failure(Exception("No channels found in response"))
            }

            Result.success(parsedChannels)
        } catch (e: Exception) {
            Log.e("ChannelRepository", "Failed to fetch channels", e)
            Result.failure(e)
        }
    }

    private fun parseServersJson(jsonString: String): List<TvChannel> {
        val channelsList = mutableListOf<TvChannel>()
        val seenUrls = mutableSetOf<String>()

        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val serverObj = jsonArray.optJSONObject(i) ?: continue
                val rawServerName = serverObj.optString("name", "General")
                val category = ChannelDataUtils.normalizeCategory(rawServerName)

                val channelsArr = serverObj.optJSONArray("channels") ?: continue
                for (j in 0 until channelsArr.length()) {
                    val chObj = channelsArr.optJSONObject(j) ?: continue

                    // Parse channel stream URL checking alternative keys
                    val streamUrl = extractStreamUrl(chObj)
                    if (streamUrl.isBlank() || seenUrls.contains(streamUrl)) {
                        continue
                    }
                    seenUrls.add(streamUrl)

                    val name = chObj.optString("name", "").trim()
                        .replace("\u200e", "")
                        .replace("\u200f", "")
                        .ifBlank { "Channel ${channelsList.size + 1}" }

                    val rawIcon = chObj.optString("icon", "").trim()
                    val icon = ChannelDataUtils.resolveChannelLogo(name, rawIcon, category)
                    val language = ChannelDataUtils.inferLanguage(category, name)
                    val description = ChannelDataUtils.generateDescription(name, category)
                    val currentProg = ChannelDataUtils.generateCurrentProgram(name, category)
                    val upcoming = ChannelDataUtils.generateUpcomingPrograms(name, category)

                    channelsList.add(
                        TvChannel(
                            id = "ch_${streamUrl.hashCode()}",
                            name = name,
                            icon = icon,
                            streamUrl = streamUrl,
                            category = category,
                            language = language,
                            description = description,
                            currentProgram = currentProg,
                            upcomingPrograms = upcoming
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("ChannelRepository", "Error parsing servers json", e)
        }

        return channelsList
    }

    private fun extractStreamUrl(obj: JSONObject): String {
        val possibleKeys = listOf("url", "streamUrl", "m3u8", "stream", "link")
        for (key in possibleKeys) {
            val v = obj.optString(key, "").trim()
            if (v.isNotBlank()) {
                return v
            }
        }
        return ""
    }

    fun isFavorite(streamUrl: String): Boolean {
        return _favoritesFlow.value.contains(streamUrl)
    }

    fun toggleFavorite(streamUrl: String) {
        val current = _favoritesFlow.value.toMutableSet()
        if (current.contains(streamUrl)) {
            current.remove(streamUrl)
        } else {
            current.add(streamUrl)
        }
        _favoritesFlow.value = current
        prefs.edit().putStringSet(KEY_FAVORITES, current).apply()
    }

    fun recordRecentlyWatched(streamUrl: String) {
        val current = _historyFlow.value.toMutableList()
        current.remove(streamUrl)
        current.add(0, streamUrl)
        if (current.size > 40) {
            current.subList(40, current.size).clear()
        }
        _historyFlow.value = current

        val arr = JSONArray()
        current.forEach { arr.put(it) }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    fun clearHistory() {
        _historyFlow.value = emptyList()
        prefs.edit().putString(KEY_HISTORY, "[]").apply()
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeedFlow.value = speed
        prefs.edit().putFloat(KEY_PLAYBACK_SPEED, speed).apply()
    }

    fun setSubtitlesEnabled(enabled: Boolean) {
        _subtitlesFlow.value = enabled
        prefs.edit().putBoolean(KEY_SUBTITLES, enabled).apply()
    }

    fun hasDismissedAboutDialog(): Boolean {
        return prefs.getBoolean(KEY_ABOUT_DIALOG_DISMISSED, false)
    }

    fun setAboutDialogDismissed() {
        prefs.edit().putBoolean(KEY_ABOUT_DIALOG_DISMISSED, true).apply()
    }

    companion object {
        private const val KEY_FAVORITES = "fav_channels_set"
        private const val KEY_HISTORY = "history_channels_list"
        private const val KEY_PLAYBACK_SPEED = "playback_speed"
        private const val KEY_SUBTITLES = "subtitles_enabled"
        private const val KEY_ABOUT_DIALOG_DISMISSED = "has_dismissed_welcome_dialog"
    }
}
