package com.example.data.model

import androidx.compose.ui.graphics.Color

data class TvChannel(
    val id: String,
    val name: String,
    val icon: String,
    val streamUrl: String,
    val category: String,
    val language: String,
    val description: String,
    val currentProgram: String,
    val upcomingPrograms: List<String>
) {
    val initials: String
        get() {
            val clean = name.trim().replace(Regex("[^a-zA-Z0-9\\s]"), "")
            val parts = clean.split("\\s+".toRegex()).filter { it.isNotBlank() }
            return when {
                parts.isEmpty() -> if (name.isNotBlank()) name.take(2).uppercase() else "TV"
                parts.size == 1 -> parts[0].take(3).uppercase()
                else -> (parts[0].take(1) + parts[1].take(1)).uppercase()
            }
        }

    val avatarColor: Color
        get() {
            val palette = listOf(
                Color(0xFFE53935),
                Color(0xFF8E24AA),
                Color(0xFF3949AB),
                Color(0xFF1E88E5),
                Color(0xFF00897B),
                Color(0xFF43A047),
                Color(0xFFFB8C00),
                Color(0xFFD81B60),
                Color(0xFF5E35B1),
                Color(0xFF00ACC1)
            )
            val index = (name.hashCode().coerceAtLeast(0)) % palette.size
            return palette[index]
        }
}

object ChannelDataUtils {
    fun normalizeCategory(rawServerName: String): String {
        val normalized = java.text.Normalizer.normalize(rawServerName, java.text.Normalizer.Form.NFKD)
        val s = normalized.trim()
        val lower = s.lowercase()
        return when {
            lower.contains("sport") -> "Sports"
            lower.contains("news") -> "News"
            lower.contains("kid") -> "Kids"
            lower.contains("movie") || lower.contains("cinema") -> "Movies"
            lower.contains("ইন্ডিয়া") || lower.contains("বাংলা") || lower.contains("bangla") -> "Bengali"
            lower.contains("hindi") -> "Hindi"
            lower.contains("islam") -> "Islamic"
            lower.contains("bachelor") || lower.contains("drama") || lower.contains("series") -> "Series"
            lower.contains("all") -> "General"
            else -> {
                val clean = s.replace(Regex("[^a-zA-Z0-9\\s]"), "").trim()
                if (clean.isBlank()) "Live TV" else clean.take(15)
            }
        }
    }

    fun resolveChannelLogo(name: String, rawIcon: String, category: String): String {
        var cleanIcon = rawIcon.trim()
        if (cleanIcon.startsWith("://")) {
            cleanIcon = "https$cleanIcon"
        } else if (cleanIcon.startsWith("postimg.cc/")) {
            cleanIcon = "https://$cleanIcon"
        } else if (cleanIcon.contains("github.com") && cleanIcon.contains("/blob/")) {
            cleanIcon = cleanIcon.replace("github.com", "raw.githubusercontent.com").replace("/blob/", "/")
        }

        // If the URL is obviously bogus (like single letter "d")
        if (cleanIcon.length < 8 || !cleanIcon.startsWith("http")) {
            cleanIcon = ""
        }

        val lower = name.lowercase().trim()
        val mappedLogo = when {
            lower.contains("btv news") -> "https://upload.wikimedia.org/wikipedia/en/thumb/e/e0/Bangladesh_Television_%28logo%29.svg/512px-Bangladesh_Television_%28logo%29.svg.png"
            lower == "btv" || lower.startsWith("btv ") -> "https://upload.wikimedia.org/wikipedia/en/thumb/e/e0/Bangladesh_Television_%28logo%29.svg/512px-Bangladesh_Television_%28logo%29.svg.png"
            lower.contains("mohana") -> "https://upload.wikimedia.org/wikipedia/en/thumb/d/d2/Mohona_Television_Logo.png/512px-Mohona_Television_Logo.png"
            lower.contains("rajdhani") -> "https://i.postimg.cc/0QRnM89n/20240825-071012.png"
            lower.contains("banglavision") -> "https://upload.wikimedia.org/wikipedia/en/thumb/4/44/Banglavision_logo.svg/512px-Banglavision_logo.svg.png"
            lower.contains("ntv") || lower.contains("n tv") -> "https://upload.wikimedia.org/wikipedia/en/thumb/9/90/NTV_Bangladesh_Logo.svg/512px-NTV_Bangladesh_Logo.svg.png"
            lower.contains("channel s") -> "https://upload.wikimedia.org/wikipedia/en/thumb/1/1a/Channel_S_logo.svg/512px-Channel_S_logo.svg.png"
            lower.contains("me tv") || lower == "metv" -> "https://upload.wikimedia.org/wikipedia/en/thumb/a/a2/MeTV_logo.svg/512px-MeTV_logo.svg.png"
            lower.contains("quran") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Quran_Hadeeth_TV_Logo.png/512px-Quran_Hadeeth_TV_Logo.png"
            lower.contains("sony pix") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Sony_Pix_logo.svg/512px-Sony_Pix_logo.svg.png"
            lower.contains("somoy") -> "https://upload.wikimedia.org/wikipedia/en/thumb/c/c5/Somoy_TV_logo.svg/512px-Somoy_TV_logo.svg.png"
            lower.contains("jamuna") -> "https://upload.wikimedia.org/wikipedia/en/thumb/5/53/Jamuna_Television_logo.svg/512px-Jamuna_Television_logo.svg.png"
            lower.contains("ekattor") || lower.contains("71 tv") -> "https://upload.wikimedia.org/wikipedia/en/thumb/c/c0/Ekattor_TV_logo.png/512px-Ekattor_TV_logo.png"
            lower.contains("dbc") -> "https://upload.wikimedia.org/wikipedia/en/thumb/5/56/DBC_News_logo.png/512px-DBC_News_logo.png"
            lower.contains("news 24") || lower.contains("news24") -> "https://upload.wikimedia.org/wikipedia/en/thumb/c/cf/News24_BD_Logo.png/512px-News24_BD_Logo.png"
            lower.contains("independent") -> "https://upload.wikimedia.org/wikipedia/en/thumb/5/52/Independent_Television_logo.png/512px-Independent_Television_logo.png"
            lower.contains("maasranga") -> "https://upload.wikimedia.org/wikipedia/en/thumb/0/05/Maasranga_TV_logo.png/512px-Maasranga_TV_logo.png"
            lower.contains("boishakhi") -> "https://upload.wikimedia.org/wikipedia/en/thumb/6/67/Boishakhi_Television_logo.png/512px-Boishakhi_Television_logo.png"
            lower.contains("ananda") -> "https://upload.wikimedia.org/wikipedia/en/thumb/5/59/Ananda_TV_logo.png/512px-Ananda_TV_logo.png"
            lower.contains("gazi") || lower.contains("gtv") -> "https://upload.wikimedia.org/wikipedia/en/thumb/4/46/Gazi_TV_logo.png/512px-Gazi_TV_logo.png"
            lower.contains("atn bangla") -> "https://raw.githubusercontent.com/ahan443/logo/refs/heads/main/atn%20bangla.png"
            lower.contains("atn news") -> "https://upload.wikimedia.org/wikipedia/en/thumb/d/d4/ATN_News_logo.png/512px-ATN_News_logo.png"
            lower.contains("ekushe") -> "https://upload.wikimedia.org/wikipedia/en/thumb/3/3f/Ekushey_Television_logo.png/512px-Ekushey_Television_logo.png"
            lower.contains("zee bangla") -> "https://upload.wikimedia.org/wikipedia/en/thumb/9/91/Zee_Bangla_Logo_2017.png/512px-Zee_Bangla_Logo_2017.png"
            lower.contains("star jalsha") -> "https://upload.wikimedia.org/wikipedia/en/thumb/2/22/Star_Jalsha_logo.png/512px-Star_Jalsha_logo.png"
            lower.contains("colors bangla") -> "https://upload.wikimedia.org/wikipedia/en/thumb/9/9a/Colors_Bangla_Logo.png/512px-Colors_Bangla_Logo.png"
            lower.contains("sony aath") -> "https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Sony_AATH_Logo.png/512px-Sony_AATH_Logo.png"
            lower.contains("hbo") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/HBO_logo.svg/512px-HBO_logo.svg.png"
            lower.contains("t sports") -> "https://upload.wikimedia.org/wikipedia/en/thumb/8/87/T_Sports_logo.png/512px-T_Sports_logo.png"
            lower.contains("ten 1") || lower.contains("sony ten") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Sony_Sports_Ten_1.svg/512px-Sony_Sports_Ten_1.svg.png"
            lower.contains("star sports") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Star_Sports_1_logo.png/512px-Star_Sports_1_logo.png"
            lower.contains("bein sports") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/BeIN_Sports_logo.svg/512px-BeIN_Sports_logo.svg.png"
            lower.contains("red bull") -> "https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/international/red-bull-tv-int.png"
            lower.contains("peace tv") -> "https://upload.wikimedia.org/wikipedia/en/thumb/0/07/Peace_TV_logo.svg/512px-Peace_TV_logo.svg.png"
            lower.contains("pogo") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Pogo_logo.svg/512px-Pogo_logo.svg.png"
            lower.contains("duronto") -> "https://upload.wikimedia.org/wikipedia/en/thumb/8/89/Duronto_TV_logo.png/512px-Duronto_TV_logo.png"
            lower.contains("discovery") -> "https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Discovery_Kids_logo_2019.svg/512px-Discovery_Kids_logo_2019.svg.png"
            lower.contains("public movie") || lower.contains("public music") -> "https://i.postimg.cc/7ZNqRywh/20240823-023440.png"
            lower.contains("epic music") -> "https://i.postimg.cc/t47SV77h/image.png"
            lower.contains("ptc music") -> "https://i.postimg.cc/NFKqPkBP/image.png"
            else -> ""
        }

        if (mappedLogo.isNotBlank()) {
            return mappedLogo
        }

        return if (cleanIcon.isNotBlank()) cleanIcon else ""
    }

    fun inferLanguage(category: String, name: String): String {
        val lower = name.lowercase()
        return when {
            category == "Bengali" || lower.contains("bangla") || lower.contains("somoy") || lower.contains("btv") || lower.contains("jamuna") -> "Bengali"
            category == "Hindi" || lower.contains("star plus") || lower.contains("zee") && !lower.contains("bangla") -> "Hindi"
            category == "Islamic" -> "Arabic / Bengali"
            category == "Sports" -> "English / Multi"
            category == "Movies" -> "English"
            category == "Kids" -> "Multi-language"
            else -> "English"
        }
    }

    fun generateDescription(name: String, category: String): String {
        return "Watch $name live 24/7 in high definition. Streaming official broadcast coverage featuring prime programming, special events, and top entertainment in the $category category on RIC TV."
    }

    fun generateCurrentProgram(name: String, category: String): String {
        return when (category) {
            "Sports" -> "Live Match: Prime Tournament Highlights & Commentary"
            "News" -> "Prime News Hour: Global & National Headlines 24/7"
            "Kids" -> "Cartoon Bonanza: Non-stop Adventure & Fun"
            "Movies" -> "Prime Cinema: Blockbuster Feature Presentation"
            "Bengali" -> "Shondhar Natok: Prime Drama Special"
            "Hindi" -> "Prime Express: Top Drama Series Tonight"
            "Islamic" -> "Live Recitation & Spiritual Reflections"
            "Series" -> "Exclusive Episode Marathon: Season Premiere"
            else -> "Live Broadcast: Prime Special Programming"
        }
    }

    fun generateUpcomingPrograms(name: String, category: String): List<String> {
        return when (category) {
            "Sports" -> listOf(
                "09:00 PM - Live Pre-Match Analysis",
                "10:30 PM - Championship Match Kickoff",
                "01:00 AM - Highlights & Post-Match Debate"
            )
            "News" -> listOf(
                "08:00 PM - Breaking Headlines & Debate",
                "10:00 PM - Special Investigation Report",
                "11:30 PM - Night Bulletin & Weather Outlook"
            )
            "Kids" -> listOf(
                "06:30 PM - Superhero Team Assemble",
                "07:30 PM - Bedtime Animated Tales",
                "08:30 PM - Weekend Special Feature"
            )
            "Movies" -> listOf(
                "08:00 PM - Hollywood Action Thriller",
                "10:45 PM - Classic Cinema Special",
                "01:15 AM - Late Night Indie Spotlight"
            )
            else -> listOf(
                "08:30 PM - Evening Prime Series",
                "10:00 PM - Special Feature Tonight",
                "11:30 PM - Late Night Entertainment"
            )
        }
    }
}
