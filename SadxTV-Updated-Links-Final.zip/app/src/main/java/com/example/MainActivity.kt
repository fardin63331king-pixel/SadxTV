package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.TvChannel
import com.example.ui.components.AboutWelcomeDialog
import com.example.ui.components.BottomNavBar
import com.example.ui.components.HeaderBar
import com.example.ui.player.PlayerScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.FricTvTheme
import com.example.ui.theme.TvAccent
import com.example.ui.theme.TvBackground
import com.example.ui.theme.TvElevated
import com.example.ui.theme.TvText
import com.example.ui.theme.TvTextSecondary
import com.example.viewmodel.ChannelsUiState
import com.example.viewmodel.MainTab
import com.example.viewmodel.TvViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FricTvTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(
    viewModel: TvViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val playerChannel by viewModel.playerChannel.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val favoriteChannels by viewModel.favoriteChannels.collectAsState()
    val recentlyWatchedChannels by viewModel.recentlyWatchedChannels.collectAsState()
    val playbackSpeed by viewModel.playbackSpeed.collectAsState()
    val subtitlesEnabled by viewModel.subtitlesEnabled.collectAsState()
    val showWelcomeDialog by viewModel.showWelcomeDialog.collectAsState()

    var showSplash by rememberSaveable { mutableStateOf(true) }

    // 0. SPLASH SCREEN (displays at app open while channels load in the background)
    if (showSplash) {
        SplashScreen(
            uiState = uiState,
            onRetry = { viewModel.refreshChannels() },
            onSplashFinished = { showSplash = false }
        )
        return
    }

    // 0.1 WELCOME / ABOUT DIALOG (shows automatically on Home page after splash, crosses out permanently)
    if (showWelcomeDialog && playerChannel == null) {
        AboutWelcomeDialog(
            onDismiss = { viewModel.dismissWelcomeDialog() }
        )
    }

    // 1. YOUTUBE-STYLE TOP VIDEO PLAYER (with scrollable channel list below)
    if (playerChannel != null) {
        val allChannels = if (uiState is ChannelsUiState.Success) {
            (uiState as ChannelsUiState.Success).allChannels
        } else {
            emptyList()
        }
        val categories = if (uiState is ChannelsUiState.Success) {
            (uiState as ChannelsUiState.Success).categories
        } else {
            listOf("All")
        }

        PlayerScreen(
            channel = playerChannel!!,
            allChannels = allChannels,
            categories = categories,
            isFavorite = viewModel.isFavorite(playerChannel!!),
            onBack = { viewModel.closePlayer() },
            onChannelSelected = { viewModel.playChannel(it) },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            initialPlaybackSpeed = playbackSpeed,
            onSpeedChanged = { viewModel.setPlaybackSpeed(it) }
        )
        return
    }

    // Intercept Back button when searching or on sub-tabs
    BackHandler(enabled = isSearchActive || currentTab != MainTab.HOME) {
        if (isSearchActive) {
            viewModel.toggleSearch(false)
        } else if (currentTab != MainTab.HOME) {
            viewModel.selectTab(MainTab.HOME)
        }
    }

    // 2. MAIN APP LAYOUT (Header + Middle Content + 4-item Modern Footer)
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TvBackground),
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                HeaderBar(
                    isSearching = isSearchActive,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.setSearchQuery(it) },
                    onSearchToggle = { active ->
                        viewModel.toggleSearch(active)
                        if (active && currentTab != MainTab.LIVE_TV) {
                            viewModel.selectTab(MainTab.LIVE_TV)
                        }
                    }
                )
            }
        },
        bottomBar = {
            BottomNavBar(
                currentTab = currentTab,
                onTabSelected = { tab ->
                    viewModel.selectTab(tab)
                    if (isSearchActive && tab != MainTab.LIVE_TV) {
                        viewModel.toggleSearch(false)
                    }
                }
            )
        },
        containerColor = TvBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val state = uiState) {
                is ChannelsUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                color = TvAccent,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(52.dp)
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                            Text(
                                text = "Loading Live Channels...",
                                color = TvText,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Connecting to real-time broadcast servers",
                                color = TvTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                is ChannelsUiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(TvElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WifiOff,
                                    contentDescription = null,
                                    tint = TvAccent,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Connection Failed",
                                color = TvText,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = state.message,
                                color = TvTextSecondary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Button(
                                onClick = { viewModel.refreshChannels() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TvAccent,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Retry Connection",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                is ChannelsUiState.Success -> {
                    when (currentTab) {
                        MainTab.HOME -> {
                            HomeScreen(
                                channels = state.allChannels,
                                categories = state.categories,
                                featuredChannel = state.featuredChannel,
                                selectedCategory = selectedCategory,
                                onSelectCategory = { viewModel.selectCategory(it) },
                                favoriteUrls = favorites,
                                onChannelClick = { viewModel.playChannel(it) },
                                onWatchClick = { viewModel.playChannel(it) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) }
                            )
                        }

                        MainTab.LIVE_TV -> {
                            LiveTvScreen(
                                channels = state.allChannels,
                                categories = state.categories,
                                selectedCategory = selectedCategory,
                                onSelectCategory = { viewModel.selectCategory(it) },
                                searchQuery = searchQuery,
                                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                favoriteUrls = favorites,
                                onChannelClick = { viewModel.playChannel(it) },
                                onWatchClick = { viewModel.playChannel(it) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) }
                            )
                        }

                        MainTab.FAVORITES -> {
                            FavoritesScreen(
                                favoriteChannels = favoriteChannels,
                                recentlyWatched = recentlyWatchedChannels,
                                favoriteUrls = favorites,
                                onChannelClick = { viewModel.playChannel(it) },
                                onWatchClick = { viewModel.playChannel(it) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onClearHistory = { viewModel.clearHistory() },
                                onExploreChannelsClick = { viewModel.selectTab(MainTab.LIVE_TV) }
                            )
                        }

                        MainTab.PROFILE -> {
                            ProfileScreen(
                                recentlyWatched = recentlyWatchedChannels,
                                currentSpeed = playbackSpeed,
                                onSpeedChange = { viewModel.setPlaybackSpeed(it) },
                                subtitlesEnabled = subtitlesEnabled,
                                onSubtitlesToggle = { viewModel.setSubtitlesEnabled(it) },
                                onClearHistory = { viewModel.clearHistory() },
                                onSelectRecentChannel = { viewModel.playChannel(it) },
                                onOpenWelcomeDialog = { viewModel.openWelcomeDialog() }
                            )
                        }
                    }
                }
            }
        }
    }
}
