package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.TvChannel
import com.example.data.repository.ChannelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ChannelsUiState {
    data object Loading : ChannelsUiState
    data class Success(
        val allChannels: List<TvChannel>,
        val categories: List<String>,
        val featuredChannel: TvChannel?
    ) : ChannelsUiState
    data class Error(val message: String) : ChannelsUiState
}

enum class MainTab {
    HOME,
    LIVE_TV,
    FAVORITES,
    PROFILE
}

class TvViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ChannelRepository(application.applicationContext)

    private val _uiState = MutableStateFlow<ChannelsUiState>(ChannelsUiState.Loading)
    val uiState: StateFlow<ChannelsUiState> = _uiState.asStateFlow()

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()

    private val _detailsChannel = MutableStateFlow<TvChannel?>(null)
    val detailsChannel: StateFlow<TvChannel?> = _detailsChannel.asStateFlow()

    private val _playerChannel = MutableStateFlow<TvChannel?>(null)
    val playerChannel: StateFlow<TvChannel?> = _playerChannel.asStateFlow()

    val favorites: StateFlow<Set<String>> = repository.favoritesFlow
    val historyUrls: StateFlow<List<String>> = repository.historyFlow
    val playbackSpeed: StateFlow<Float> = repository.playbackSpeedFlow
    val subtitlesEnabled: StateFlow<Boolean> = repository.subtitlesFlow

    private val _showWelcomeDialog = MutableStateFlow(!repository.hasDismissedAboutDialog())
    val showWelcomeDialog: StateFlow<Boolean> = _showWelcomeDialog.asStateFlow()

    fun dismissWelcomeDialog() {
        _showWelcomeDialog.value = false
        repository.setAboutDialogDismissed()
    }

    fun openWelcomeDialog() {
        _showWelcomeDialog.value = true
    }

    // Derived list of favorite channels
    val favoriteChannels: StateFlow<List<TvChannel>> = combine(_uiState, favorites) { state, favs ->
        if (state is ChannelsUiState.Success) {
            state.allChannels.filter { favs.contains(it.streamUrl) }
        } else {
            emptyList()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Derived list of recently watched channels
    val recentlyWatchedChannels: StateFlow<List<TvChannel>> = combine(_uiState, historyUrls) { state, hist ->
        if (state is ChannelsUiState.Success) {
            val map = state.allChannels.associateBy { it.streamUrl }
            hist.mapNotNull { map[it] }
        } else {
            emptyList()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        refreshChannels()
    }

    fun refreshChannels() {
        viewModelScope.launch {
            _uiState.value = ChannelsUiState.Loading
            val result = repository.fetchChannels()
            result.onSuccess { channels ->
                val categories = buildList {
                    add("All")
                    val set = channels.map { it.category }.distinct().sorted()
                    addAll(set)
                }
                // Pick a premier sports or entertainment or news channel as featured
                val featured = channels.firstOrNull { it.category == "Sports" }
                    ?: channels.firstOrNull { it.icon.isNotBlank() }
                    ?: channels.firstOrNull()

                _uiState.value = ChannelsUiState.Success(
                    allChannels = channels,
                    categories = categories,
                    featuredChannel = featured
                )
            }.onFailure { err ->
                _uiState.value = ChannelsUiState.Error(
                    err.localizedMessage ?: "Unable to connect to live TV servers. Please check your internet connection."
                )
            }
        }
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun selectCategory(cat: String) {
        _selectedCategory.value = cat
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleSearch(active: Boolean) {
        _isSearchActive.value = active
        if (!active) {
            _searchQuery.value = ""
        }
    }

    fun openDetails(channel: TvChannel) {
        _detailsChannel.value = channel
    }

    fun closeDetails() {
        _detailsChannel.value = null
    }

    fun playChannel(channel: TvChannel) {
        _playerChannel.value = channel
        repository.recordRecentlyWatched(channel.streamUrl)
    }

    fun closePlayer() {
        _playerChannel.value = null
    }

    fun playNextChannel() {
        val current = _playerChannel.value ?: return
        val state = _uiState.value
        if (state is ChannelsUiState.Success) {
            val list = state.allChannels
            val idx = list.indexOfFirst { it.streamUrl == current.streamUrl }
            if (idx != -1 && list.isNotEmpty()) {
                val nextIdx = (idx + 1) % list.size
                val next = list[nextIdx]
                playChannel(next)
            }
        }
    }

    fun playPreviousChannel() {
        val current = _playerChannel.value ?: return
        val state = _uiState.value
        if (state is ChannelsUiState.Success) {
            val list = state.allChannels
            val idx = list.indexOfFirst { it.streamUrl == current.streamUrl }
            if (idx != -1 && list.isNotEmpty()) {
                val prevIdx = if (idx - 1 < 0) list.size - 1 else idx - 1
                val prev = list[prevIdx]
                playChannel(prev)
            }
        }
    }

    fun toggleFavorite(channel: TvChannel) {
        repository.toggleFavorite(channel.streamUrl)
    }

    fun isFavorite(channel: TvChannel): Boolean {
        return repository.isFavorite(channel.streamUrl)
    }

    fun clearHistory() {
        repository.clearHistory()
    }

    fun setPlaybackSpeed(speed: Float) {
        repository.setPlaybackSpeed(speed)
    }

    fun setSubtitlesEnabled(enabled: Boolean) {
        repository.setSubtitlesEnabled(enabled)
    }
}
