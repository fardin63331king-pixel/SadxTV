package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TvChannel
import com.example.ui.components.CategoryChips
import com.example.ui.components.ChannelAvatar
import com.example.ui.components.ChannelBroadcastThumbnail
import com.example.ui.components.ChannelCard
import com.example.ui.components.ChannelCarouselCard
import com.example.ui.components.LiveBadge
import androidx.compose.ui.text.style.TextOverflow
import com.example.ui.theme.TvAccent
import com.example.ui.theme.TvBackground
import com.example.ui.theme.TvCardBorder
import com.example.ui.theme.TvElevated
import com.example.ui.theme.TvSecondary
import com.example.ui.theme.TvSurface
import com.example.ui.theme.TvText
import com.example.ui.theme.TvTextSecondary

@Composable
fun HomeScreen(
    channels: List<TvChannel>,
    categories: List<String>,
    featuredChannel: TvChannel?,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    favoriteUrls: Set<String>,
    onChannelClick: (TvChannel) -> Unit,
    onWatchClick: (TvChannel) -> Unit,
    onToggleFavorite: (TvChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredChannels = androidx.compose.runtime.remember(channels, selectedCategory) {
        if (selectedCategory.equals("All", ignoreCase = true)) {
            channels
        } else {
            channels.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
    }

    val liveNowList = androidx.compose.runtime.remember(channels) {
        channels.take(10)
    }

    val chunkedChannels = androidx.compose.runtime.remember(filteredChannels) {
        filteredChannels.chunked(2)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TvBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Featured Hero Banner
        if (featuredChannel != null) {
            item {
                FeaturedChannelBanner(
                    channel = featuredChannel,
                    onWatchClick = onWatchClick,
                    onChannelClick = onChannelClick
                )
            }
        }

        // Live Now Section Header & Carousel
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Whatshot,
                    contentDescription = null,
                    tint = TvAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Live Now",
                    color = TvText,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(liveNowList, key = { it.streamUrl }) { channel ->
                    ChannelCarouselCard(
                        channel = channel,
                        isFavorite = favoriteUrls.contains(channel.streamUrl),
                        onChannelClick = onChannelClick,
                        onWatchClick = onWatchClick
                    )
                }
            }
        }

        // Category Filter Chips
        item {
            Spacer(modifier = Modifier.height(16.dp))
            CategoryChips(
                categories = categories,
                selectedCategory = selectedCategory,
                onSelectCategory = onSelectCategory
            )
        }

        // Channels Section Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedCategory == "All") "All Channels" else "$selectedCategory Channels",
                    color = TvText,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${filteredChannels.size} live",
                    color = TvTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Channel Grid (using chunks of 2 for smooth nested scrolling in LazyColumn)
        items(
            items = chunkedChannels,
            key = { pair -> pair.firstOrNull()?.streamUrl ?: pair.hashCode() }
        ) { pair ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (channel in pair) {
                    Box(modifier = Modifier.weight(1f)) {
                        ChannelCard(
                            channel = channel,
                            isFavorite = favoriteUrls.contains(channel.streamUrl),
                            onChannelClick = onChannelClick,
                            onWatchClick = onWatchClick,
                            onToggleFavorite = onToggleFavorite
                        )
                    }
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun FeaturedChannelBanner(
    channel: TvChannel,
    onWatchClick: (TvChannel) -> Unit,
    onChannelClick: (TvChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF281119),
                        TvElevated,
                        TvSurface
                    )
                )
            )
            .border(1.dp, TvCardBorder, RoundedCornerShape(20.dp))
            .clickable { onChannelClick(channel) }
            .padding(20.dp)
            .testTag("featured_banner")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LiveBadge(text = "FEATURED LIVE")

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x33FFA000))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = channel.category,
                        color = TvSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Featured Channel 16:9 Broadcast Thumbnail
            ChannelBroadcastThumbnail(
                channel = channel,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = channel.name,
                        color = TvText,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = channel.currentProgram,
                        color = TvTextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Button(
                    onClick = { onWatchClick(channel) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TvAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Watch",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
