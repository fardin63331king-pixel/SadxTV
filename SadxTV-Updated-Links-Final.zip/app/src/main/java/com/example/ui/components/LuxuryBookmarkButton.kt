package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TvAccent
import com.example.ui.theme.TvCardBorder
import com.example.ui.theme.TvElevated
import com.example.ui.theme.TvText
import com.example.ui.theme.TvTextSecondary

/**
 * Luxury Floating Bookmark Button for Channel Cards and Carousels.
 * Replaces plain stock icon buttons with a frosted glass glow badge.
 */
@Composable
fun LuxuryBookmarkButton(
    isFavorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    testTag: String = "luxury_bookmark_button"
) {
    val scale by animateFloatAsState(
        targetValue = if (isFavorite) 1.08f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "bookmark_scale"
    )

    val bgColor = if (isFavorite) {
        Color(0x33FF2E93)
    } else {
        Color(0x22FFFFFF)
    }

    val borderColor = if (isFavorite) {
        TvAccent
    } else {
        TvCardBorder
    }

    Box(
        modifier = modifier
            .size(size)
            .scale(scale)
            .clip(CircleShape)
            .background(bgColor)
            .border(1.2.dp, borderColor, CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        if (isFavorite) {
            // Glowing filled star-ribbon bookmark
            Icon(
                imageVector = Icons.Filled.Bookmark,
                contentDescription = "Saved Channel",
                tint = TvAccent,
                modifier = Modifier.size(19.dp)
            )
        } else {
            // Crisp, minimal glass bookmark
            Icon(
                imageVector = Icons.Outlined.BookmarkBorder,
                contentDescription = "Save Channel",
                tint = Color(0xFFD0D6E2),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Luxury Action Pill Button for Player Screen and Detail Headers.
 */
@Composable
fun LuxuryBookmarkPill(
    isFavorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "action_bookmark_pill"
) {
    val bgBrush = if (isFavorite) {
        Brush.horizontalGradient(
            colors = listOf(
                Color(0xFFFF2E93),
                Color(0xFFFF5E62)
            )
        )
    } else {
        Brush.horizontalGradient(
            colors = listOf(
                Color(0x2E1E2235),
                Color(0x24161824)
            )
        )
    }

    val borderStroke = if (isFavorite) {
        Color(0x88FF2E93)
    } else {
        TvCardBorder
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(bgBrush)
            .border(1.2.dp, borderStroke, RoundedCornerShape(22.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isFavorite) Icons.Filled.BookmarkAdded else Icons.Outlined.BookmarkBorder,
                contentDescription = null,
                tint = if (isFavorite) Color.White else Color(0xFFD0D6E2),
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isFavorite) "Saved" else "Save",
                color = if (isFavorite) Color.White else TvText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
