package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TvBackground = Color(0xFF070809)
val TvSurface = Color(0xFF10110D)
val TvElevated = Color(0xFF1A170D)
val TvSurfaceVariant = Color(0xFF282111)
val TvAccent = Color(0xFFFFC52E)
val TvAccentDark = Color(0xFFE0A900)
val TvSecondary = Color(0xFFFFE082)
val TvText = Color(0xFFFFFFFF)
val TvTextSecondary = Color(0xFFB8B2A0)
val TvTextMuted = Color(0xFF746B55)
val TvCardBorder = Color(0xFF3A3018)
val TvLiveGreen = Color(0xFFB8F36B)
val TvPlayerOverlay = Color(0xE0050608)
