package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TvChannel
import com.example.ui.theme.TvAccent
import com.example.ui.theme.TvCardBorder
import com.example.ui.theme.TvElevated
import com.example.ui.theme.TvSecondary
import com.example.ui.theme.TvSurface
import com.example.ui.theme.TvText
import com.example.ui.theme.TvTextSecondary

@Composable
fun ChannelCard(
    channel: TvChannel,
    isFavorite: Boolean,
    onChannelClick: (TvChannel) -> Unit,
    onWatchClick: (TvChannel) -> Unit,
    onToggleFavorite: (TvChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TvSurface)
            .border(1.dp, TvCardBorder, RoundedCornerShape(16.dp))
            .clickable { onChannelClick(channel) }
            .testTag("channel_card_${channel.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // 1. Prominent Visual Broadcast Image Thumbnail (Guaranteed Image, never empty)
            ChannelBroadcastThumbnail(channel = channel)

            // 2. Channel Info & Actions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = channel.name,
                            color = TvText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${channel.category} • ${channel.language}",
                            color = TvTextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Luxury Glass Floating Bookmark Button
                    LuxuryBookmarkButton(
                        isFavorite = isFavorite,
                        onClick = { onToggleFavorite(channel) },
                        testTag = "bookmark_btn_${channel.id}"
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Watch Live Action
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TvElevated)
                        .clickable { onWatchClick(channel) }
                        .padding(vertical = 7.dp, horizontal = 10.dp)
                        .testTag("watch_now_btn_${channel.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = TvAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Watch Live",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelCarouselCard(
    channel: TvChannel,
    isFavorite: Boolean,
    onChannelClick: (TvChannel) -> Unit,
    onWatchClick: (TvChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(170.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(TvSurface)
            .border(1.dp, TvCardBorder, RoundedCornerShape(16.dp))
            .clickable { onChannelClick(channel) }
            .testTag("carousel_card_${channel.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Visual Image Thumbnail
            ChannelBroadcastThumbnail(
                channel = channel,
                modifier = Modifier.fillMaxWidth()
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = channel.name,
                    color = TvText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = channel.category,
                    color = TvTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(TvAccent)
                        .clickable { onWatchClick(channel) }
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Watch Live",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
