package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.remember
import coil.compose.AsyncImage
import coil.decode.SvgDecoder
import coil.request.ImageRequest
import com.example.data.model.TvChannel
import com.example.ui.theme.TvAccent
import com.example.ui.theme.TvCardBorder
import com.example.ui.theme.TvElevated
import com.example.ui.theme.TvSecondary
import com.example.ui.theme.TvSurface
import com.example.ui.theme.TvText
import com.example.ui.theme.TvTextSecondary

@Composable
fun ChannelAvatar(
    channel: TvChannel,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    shape: Shape = RoundedCornerShape(12.dp)
) {
    val context = LocalContext.current
    val imageModel = remember(channel.icon, context) {
        val target = if (channel.icon.isNotBlank()) channel.icon else com.example.R.drawable.default_channel_logo
        ImageRequest.Builder(context)
            .data(target)
            .decoderFactory(SvgDecoder.Factory())
            .placeholder(com.example.R.drawable.default_channel_logo)
            .error(com.example.R.drawable.default_channel_logo)
            .fallback(com.example.R.drawable.default_channel_logo)
            .crossfade(100)
            .build()
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .border(1.dp, TvCardBorder, shape)
            .background(TvSurface),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = imageModel,
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
        )
    }
}

// User-provided broadcast fallback badge when image is missing or loading
@Composable
private fun TvGraphicEmblem(
    channel: TvChannel,
    size: Dp
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TvSurface)
            .padding(3.dp),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.example.R.drawable.default_channel_logo),
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    }
}

// 16:9 Rich TV Broadcast Thumbnail Banner for Channel Cards
@Composable
fun ChannelBroadcastThumbnail(
    channel: TvChannel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imageModel = remember(channel.icon, context) {
        val target = if (channel.icon.isNotBlank()) channel.icon else com.example.R.drawable.default_channel_logo
        ImageRequest.Builder(context)
            .data(target)
            .decoderFactory(SvgDecoder.Factory())
            .placeholder(com.example.R.drawable.default_channel_logo)
            .error(com.example.R.drawable.default_channel_logo)
            .fallback(com.example.R.drawable.default_channel_logo)
            .crossfade(100)
            .build()
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF222838),
                        TvSurface
                    )
                )
            )
            .border(1.dp, TvCardBorder, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = imageModel,
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        )

        // Live Badge at Top-Right
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
        ) {
            LiveBadge()
        }

        // Category Tag at Bottom-Left
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xD9090A0E))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = channel.category,
                color = TvSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TvThumbnailCardFallback(channel: TvChannel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF181C2B),
                        Color(0xFF0F111D)
                    )
                )
            )
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.example.R.drawable.default_channel_logo),
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    }
}
