package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Bespoke Premium Streaming Icons for SadxTV Bottom Navigation.
 * Designed with precise geometric lines, rounded joints, and luxury streaming aesthetics.
 */

@Composable
fun FricHomeIcon(
    tint: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = 2.0.dp.toPx()

        val roofPath = Path().apply {
            // Slanted modern apex roof
            moveTo(w * 0.12f, h * 0.46f)
            lineTo(w * 0.50f, h * 0.16f)
            lineTo(w * 0.88f, h * 0.46f)
        }

        drawPath(
            path = roofPath,
            color = tint,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        val bodyPath = Path().apply {
            // Body of the home
            moveTo(w * 0.22f, h * 0.42f)
            lineTo(w * 0.22f, h * 0.86f)
            lineTo(w * 0.78f, h * 0.86f)
            lineTo(w * 0.78f, h * 0.42f)
        }

        if (isSelected) {
            // Filled modern base with sleek doorway cutout
            drawPath(
                path = bodyPath,
                color = tint,
                style = Fill
            )
            // Cutout door in background color
            drawRoundRect(
                color = Color(0xFF0F111D),
                topLeft = Offset(w * 0.40f, h * 0.56f),
                size = Size(w * 0.20f, h * 0.32f),
                cornerRadius = CornerRadius(4f, 4f)
            )
        } else {
            // Clean outlined geometric home
            drawPath(
                path = bodyPath,
                color = tint,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            // Minimal door frame
            drawRoundRect(
                color = tint,
                topLeft = Offset(w * 0.41f, h * 0.58f),
                size = Size(w * 0.18f, h * 0.28f),
                cornerRadius = CornerRadius(3f, 3f),
                style = Stroke(width = strokeWidth * 0.8f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun FricLiveTvIcon(
    tint: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = 2.0.dp.toPx()

        // Modern curved TV Screen monitor
        val screenTop = h * 0.30f
        val screenH = h * 0.56f
        val screenW = w * 0.86f
        val screenLeft = (w - screenW) / 2f

        if (isSelected) {
            // Filled monitor with glowing live broadcast beacon
            drawRoundRect(
                color = tint,
                topLeft = Offset(screenLeft, screenTop),
                size = Size(screenW, screenH),
                cornerRadius = CornerRadius(10f, 10f)
            )
            // Play/Broadcast glyph inside monitor
            val playPath = Path().apply {
                moveTo(w * 0.44f, h * 0.46f)
                lineTo(w * 0.60f, h * 0.58f)
                lineTo(w * 0.44f, h * 0.70f)
                close()
            }
            drawPath(path = playPath, color = Color(0xFF0F111D))
        } else {
            // Outlined widescreen monitor
            drawRoundRect(
                color = tint,
                topLeft = Offset(screenLeft, screenTop),
                size = Size(screenW, screenH),
                cornerRadius = CornerRadius(10f, 10f),
                style = Stroke(width = strokeWidth)
            )
            // Center play triangle
            val playPath = Path().apply {
                moveTo(w * 0.46f, h * 0.48f)
                lineTo(w * 0.58f, h * 0.58f)
                lineTo(w * 0.46f, h * 0.68f)
                close()
            }
            drawPath(path = playPath, color = tint)
        }

        // Dual Antenna Rays on Top
        drawLine(
            color = tint,
            start = Offset(w * 0.32f, screenTop),
            end = Offset(w * 0.22f, h * 0.12f),
            strokeWidth = strokeWidth * 0.85f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.68f, screenTop),
            end = Offset(w * 0.78f, h * 0.12f),
            strokeWidth = strokeWidth * 0.85f,
            cap = StrokeCap.Round
        )

        // Steady Vibrant Red Live Dot with halo
        drawCircle(
            color = Color(0x66FF2E93),
            radius = 4.dp.toPx(),
            center = Offset(w * 0.82f, h * 0.12f)
        )
        drawCircle(
            color = Color(0xFFFF2E93),
            radius = 2.8.dp.toPx(),
            center = Offset(w * 0.82f, h * 0.12f)
        )
    }
}

@Composable
fun FricLibraryIcon(
    tint: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = 2.0.dp.toPx()

        // Luxury Ribbon Bookmark Path with sleek swallowtail notch
        val bookmarkPath = Path().apply {
            moveTo(w * 0.22f, h * 0.14f)
            lineTo(w * 0.78f, h * 0.14f)
            lineTo(w * 0.78f, h * 0.88f)
            lineTo(w * 0.50f, h * 0.68f)
            lineTo(w * 0.22f, h * 0.88f)
            close()
        }

        if (isSelected) {
            drawPath(path = bookmarkPath, color = tint, style = Fill)
            // Inset star symbol
            val starPath = Path().apply {
                moveTo(w * 0.50f, h * 0.28f)
                lineTo(w * 0.54f, h * 0.38f)
                lineTo(w * 0.65f, h * 0.38f)
                lineTo(w * 0.56f, h * 0.44f)
                lineTo(w * 0.59f, h * 0.54f)
                lineTo(w * 0.50f, h * 0.48f)
                lineTo(w * 0.41f, h * 0.54f)
                lineTo(w * 0.44f, h * 0.44f)
                lineTo(w * 0.35f, h * 0.38f)
                lineTo(w * 0.46f, h * 0.38f)
                close()
            }
            drawPath(path = starPath, color = Color(0xFF0F111D), style = Fill)
        } else {
            drawPath(
                path = bookmarkPath,
                color = tint,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            // Clean horizontal bookmark notch
            drawLine(
                color = tint,
                start = Offset(w * 0.36f, h * 0.36f),
                end = Offset(w * 0.64f, h * 0.36f),
                strokeWidth = strokeWidth * 0.9f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun FricProfileIcon(
    tint: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = 2.0.dp.toPx()

        // Outer ambient frame circle
        drawCircle(
            color = if (isSelected) tint else tint.copy(alpha = 0.4f),
            radius = w * 0.44f,
            center = Offset(w * 0.5f, h * 0.5f),
            style = Stroke(width = if (isSelected) strokeWidth * 1.1f else strokeWidth * 0.8f)
        )

        // Head
        val headRadius = w * 0.17f
        val headCenter = Offset(w * 0.5f, h * 0.38f)
        if (isSelected) {
            drawCircle(color = tint, radius = headRadius, center = headCenter)
        } else {
            drawCircle(
                color = tint,
                radius = headRadius,
                center = headCenter,
                style = Stroke(width = strokeWidth)
            )
        }

        // Torso / Shoulders arc
        val torsoPath = Path().apply {
            moveTo(w * 0.28f, h * 0.78f)
            quadraticTo(w * 0.28f, h * 0.58f, w * 0.50f, h * 0.58f)
            quadraticTo(w * 0.72f, h * 0.58f, w * 0.72f, h * 0.78f)
        }

        if (isSelected) {
            torsoPath.lineTo(w * 0.28f, h * 0.78f)
            drawPath(path = torsoPath, color = tint, style = Fill)
        } else {
            drawPath(
                path = torsoPath,
                color = tint,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
    }
}
