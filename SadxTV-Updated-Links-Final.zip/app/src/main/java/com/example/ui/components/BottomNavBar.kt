package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TvAccent
import com.example.ui.theme.TvCardBorder
import com.example.ui.theme.TvElevated
import com.example.ui.theme.TvText
import com.example.ui.theme.TvTextSecondary
import com.example.viewmodel.MainTab

private enum class FricNavTab(val tab: MainTab, val title: String, val testTag: String) {
    HOME(MainTab.HOME, "Home", "nav_home"),
    LIVE_TV(MainTab.LIVE_TV, "Live TV", "nav_livetv"),
    FAVORITES(MainTab.FAVORITES, "Saved", "nav_favorites"),
    PROFILE(MainTab.PROFILE, "Profile", "nav_profile")
}

@Composable
fun BottomNavBar(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xF510131F),
                        Color(0xFF0A0B12)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        TvCardBorder,
                        Color(0x44FF2E93),
                        Color(0x4400E5FF),
                        TvCardBorder
                    )
                ),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            )
            .navigationBarsPadding()
            .height(72.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FricNavTab.values().forEach { item ->
                val isSelected = currentTab == item.tab
                val iconColor by animateColorAsState(
                    targetValue = if (isSelected) Color.White else Color(0xFF8A93A6),
                    animationSpec = tween(220),
                    label = "icon_color"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onTabSelected(item.tab) }
                        .testTag(item.testTag),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Floating Pill Container with glowing gradient when active
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (isSelected) {
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                TvAccent,
                                                Color(0xFFFF5252)
                                            )
                                        )
                                    } else {
                                        Brush.horizontalGradient(
                                            colors = listOf(Color.Transparent, Color.Transparent)
                                        )
                                    }
                                )
                                .padding(horizontal = 18.dp, vertical = 5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            when (item) {
                                FricNavTab.HOME -> FricHomeIcon(
                                    tint = iconColor,
                                    isSelected = isSelected,
                                    size = 21.dp
                                )
                                FricNavTab.LIVE_TV -> FricLiveTvIcon(
                                    tint = iconColor,
                                    isSelected = isSelected,
                                    size = 21.dp
                                )
                                FricNavTab.FAVORITES -> FricLibraryIcon(
                                    tint = iconColor,
                                    isSelected = isSelected,
                                    size = 21.dp
                                )
                                FricNavTab.PROFILE -> FricProfileIcon(
                                    tint = iconColor,
                                    isSelected = isSelected,
                                    size = 21.dp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = item.title,
                            color = if (isSelected) Color.White else Color(0xFF8A93A6),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
