package com.example.ui.player

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.data.model.TvChannel
import com.example.ui.components.CategoryChips
import com.example.ui.components.ChannelAvatar
import com.example.ui.components.ChannelBroadcastThumbnail
import com.example.ui.components.LiveBadge
import com.example.ui.components.LuxuryBookmarkPill
import com.example.ui.theme.TvAccent
import com.example.ui.theme.TvBackground
import com.example.ui.theme.TvCardBorder
import com.example.ui.theme.TvElevated
import com.example.ui.theme.TvPlayerOverlay
import com.example.ui.theme.TvSecondary
import com.example.ui.theme.TvSurface
import com.example.ui.theme.TvText
import com.example.ui.theme.TvTextSecondary
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    channel: TvChannel,
    allChannels: List<TvChannel>,
    categories: List<String>,
    isFavorite: Boolean,
    onBack: () -> Unit,
    onChannelSelected: (TvChannel) -> Unit,
    onToggleFavorite: (TvChannel) -> Unit,
    initialPlaybackSpeed: Float = 1.0f,
    onSpeedChanged: (Float) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val activity = context as? Activity

    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var areControlsVisible by remember { mutableStateOf(true) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var totalDuration by remember { mutableLongStateOf(0L) }
    var isLiveStream by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var currentSpeed by remember { mutableFloatStateOf(initialPlaybackSpeed) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var isFullscreen by remember { mutableStateOf(false) }
    var retryTrigger by remember { mutableStateOf(0) }
    var selectedCategoryInFeed by remember { mutableStateOf("All") }

    // Intercept back button: if in fullscreen, exit fullscreen first; otherwise return back
    BackHandler {
        if (isFullscreen) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            isFullscreen = false
        } else {
            onBack()
        }
    }

    // Auto-hide controls after 4 seconds of inactivity
    LaunchedEffect(areControlsVisible, isPlaying) {
        if (areControlsVisible && isPlaying && errorMessage == null) {
            delay(4000)
            areControlsVisible = false
        }
    }

    // Build ExoPlayer instance
    val exoPlayer = remember(context) {
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setUserAgent("SadxTV-Android-Player/1.0 (Linux; Android)")

        val mediaSourceFactory = DefaultMediaSourceFactory(context)
            .setDataSourceFactory(httpDataSourceFactory)

        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().apply {
                playWhenReady = true
                playbackParameters = PlaybackParameters(currentSpeed)
            }
    }

    // Prepare stream whenever channel or retry changes
    LaunchedEffect(channel.streamUrl, retryTrigger) {
        errorMessage = null
        isBuffering = true
        try {
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(channel.streamUrl))
                .setMediaId(channel.id)
                .build()

            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.play()
        } catch (e: Exception) {
            errorMessage = e.localizedMessage ?: "Failed to initialize playback."
            isBuffering = false
        }
    }

    // Position & Duration tracking loop (only ticks when controls overlay is visible to eliminate frame drops/lag)
    LaunchedEffect(exoPlayer, areControlsVisible) {
        while (areControlsVisible) {
            currentPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration
            totalDuration = if (dur == C.TIME_UNSET || dur <= 0) 0L else dur
            isLiveStream = exoPlayer.isCurrentMediaItemLive || totalDuration <= 0L
            isPlaying = exoPlayer.isPlaying
            delay(500)
        }
    }

    // ExoPlayer event listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> isBuffering = true
                    Player.STATE_READY -> {
                        isBuffering = false
                        errorMessage = null
                    }
                    Player.STATE_ENDED -> isBuffering = false
                    Player.STATE_IDLE -> {}
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                val reason = error.cause?.localizedMessage ?: error.message ?: "Stream host is unreachable or expired."
                errorMessage = reason
            }
        }

        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
        }
    }

    // Pause on backgrounding & cleanup on exit
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> exoPlayer.pause()
                Lifecycle.Event.ON_RESUME -> {
                    if (errorMessage == null) exoPlayer.play()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            exoPlayer.stop()
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Channels list for YouTube-style scroll feed below top player
    val filteredFeed = remember(allChannels, selectedCategoryInFeed, channel.streamUrl) {
        val others = allChannels.filter { it.streamUrl != channel.streamUrl }
        if (selectedCategoryInFeed.equals("All", ignoreCase = true)) {
            others
        } else {
            others.filter { it.category.equals(selectedCategoryInFeed, ignoreCase = true) }
        }
    }

    // FULLSCREEN MODE vs YOUTUBE-STYLE TOP PLAYER MODE
    if (isFullscreen) {
        // Fullscreen view
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            PlayerViewComponent(
                exoPlayer = exoPlayer,
                modifier = Modifier.fillMaxSize()
            )

            PlayerControlsOverlay(
                channel = channel,
                isPlaying = isPlaying,
                isBuffering = isBuffering,
                errorMessage = errorMessage,
                areControlsVisible = areControlsVisible,
                currentPosition = currentPosition,
                totalDuration = totalDuration,
                isLiveStream = isLiveStream,
                isMuted = isMuted,
                currentSpeed = currentSpeed,
                isFullscreen = true,
                onTogglePlayPause = {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                },
                onRewind10s = {
                    val pos = (exoPlayer.currentPosition - 10000).coerceAtLeast(0)
                    exoPlayer.seekTo(pos)
                },
                onForward10s = {
                    exoPlayer.seekTo(exoPlayer.currentPosition + 10000)
                },
                onToggleMute = {
                    isMuted = !isMuted
                    exoPlayer.volume = if (isMuted) 0f else 1f
                },
                onOpenSpeedDialog = { showSpeedDialog = true },
                onToggleFullscreen = {
                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    isFullscreen = false
                },
                onSeekTo = { exoPlayer.seekTo(it) },
                onRetry = { retryTrigger++ },
                onPlayNext = {
                    val idx = allChannels.indexOfFirst { it.streamUrl == channel.streamUrl }
                    if (idx != -1 && allChannels.isNotEmpty()) {
                        val next = allChannels[(idx + 1) % allChannels.size]
                        onChannelSelected(next)
                    }
                },
                onPlayPrevious = {
                    val idx = allChannels.indexOfFirst { it.streamUrl == channel.streamUrl }
                    if (idx != -1 && allChannels.isNotEmpty()) {
                        val prev = if (idx - 1 < 0) allChannels.size - 1 else idx - 1
                        onChannelSelected(allChannels[prev])
                    }
                },
                onBack = {
                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    isFullscreen = false
                },
                onTapScreen = { areControlsVisible = !areControlsVisible }
            )
        }
    } else {
        // YOUTUBE-STYLE VIEW: Top Video Player + Scrollable Channel Feed Below
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(TvBackground)
                .statusBarsPadding()
        ) {
            // 1. TOP VIDEO PLAYER (16:9 Aspect Ratio)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
            ) {
                PlayerViewComponent(
                    exoPlayer = exoPlayer,
                    modifier = Modifier.fillMaxSize()
                )

                PlayerControlsOverlay(
                    channel = channel,
                    isPlaying = isPlaying,
                    isBuffering = isBuffering,
                    errorMessage = errorMessage,
                    areControlsVisible = areControlsVisible,
                    currentPosition = currentPosition,
                    totalDuration = totalDuration,
                    isLiveStream = isLiveStream,
                    isMuted = isMuted,
                    currentSpeed = currentSpeed,
                    isFullscreen = false,
                    onTogglePlayPause = {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    },
                    onRewind10s = {
                        val pos = (exoPlayer.currentPosition - 10000).coerceAtLeast(0)
                        exoPlayer.seekTo(pos)
                    },
                    onForward10s = {
                        exoPlayer.seekTo(exoPlayer.currentPosition + 10000)
                    },
                    onToggleMute = {
                        isMuted = !isMuted
                        exoPlayer.volume = if (isMuted) 0f else 1f
                    },
                    onOpenSpeedDialog = { showSpeedDialog = true },
                    onToggleFullscreen = {
                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        isFullscreen = true
                    },
                    onSeekTo = { exoPlayer.seekTo(it) },
                    onRetry = { retryTrigger++ },
                    onPlayNext = {
                        val idx = allChannels.indexOfFirst { it.streamUrl == channel.streamUrl }
                        if (idx != -1 && allChannels.isNotEmpty()) {
                            val next = allChannels[(idx + 1) % allChannels.size]
                            onChannelSelected(next)
                        }
                    },
                    onPlayPrevious = {
                        val idx = allChannels.indexOfFirst { it.streamUrl == channel.streamUrl }
                        if (idx != -1 && allChannels.isNotEmpty()) {
                            val prev = if (idx - 1 < 0) allChannels.size - 1 else idx - 1
                            onChannelSelected(allChannels[prev])
                        }
                    },
                    onBack = onBack,
                    onTapScreen = { areControlsVisible = !areControlsVisible }
                )
            }

            // 2. SCROLLABLE CONTENT BELOW TOP PLAYER (Like YouTube)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(TvBackground),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // Channel Title & Info Header
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                ChannelAvatar(
                                    channel = channel,
                                    size = 46.dp,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = channel.name,
                                        color = TvText,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = channel.category,
                                            color = TvSecondary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = " • ${channel.language}",
                                            color = TvTextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            LiveBadge()
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick Action Buttons Row (Favorite, Share, Speed, Mute)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Luxury Bookmark Pill
                            LuxuryBookmarkPill(
                                isFavorite = isFavorite,
                                onClick = { onToggleFavorite(channel) },
                                testTag = "action_bookmark"
                            )

                            // Share / Copy Link Button
                            ActionPillButton(
                                icon = Icons.Default.Share,
                                text = "Share",
                                iconTint = TvText,
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Channel Link", channel.streamUrl)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "Stream link copied!", Toast.LENGTH_SHORT).show()
                                },
                                testTag = "action_share"
                            )

                            // Playback Speed Button
                            ActionPillButton(
                                icon = Icons.Default.Speed,
                                text = "${currentSpeed}x",
                                iconTint = TvSecondary,
                                onClick = { showSpeedDialog = true },
                                testTag = "action_speed"
                            )

                            // Fullscreen expand Button
                            ActionPillButton(
                                icon = Icons.Default.Fullscreen,
                                text = "Expand",
                                iconTint = TvText,
                                onClick = {
                                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    isFullscreen = true
                                },
                                testTag = "action_fullscreen"
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Current Program Description Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(TvSurface)
                                .border(1.dp, TvCardBorder, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.Top) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(TvElevated),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Tv,
                                        contentDescription = null,
                                        tint = TvAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = channel.currentProgram,
                                        color = TvText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = channel.description,
                                        color = TvTextSecondary,
                                        fontSize = 12.sp,
                                        lineHeight = 17.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                // Section Title: "Up Next / More Channels" (YouTube style)
                item {
                    Text(
                        text = "More Live Channels",
                        color = TvText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp)
                    )
                }

                // Category Filter Chips
                item {
                    CategoryChips(
                        categories = categories,
                        selectedCategory = selectedCategoryInFeed,
                        onSelectCategory = { selectedCategoryInFeed = it }
                    )
                }

                // YouTube-style Recommended Channel Feed (scrollable list)
                items(filteredFeed, key = { it.streamUrl }) { itemChannel ->
                    YouTubeChannelFeedItem(
                        channel = itemChannel,
                        isCurrent = itemChannel.streamUrl == channel.streamUrl,
                        onClick = {
                            onChannelSelected(itemChannel)
                        }
                    )
                }
            }
        }
    }

    // Playback Speed Dialog
    if (showSpeedDialog) {
        Dialog(onDismissRequest = { showSpeedDialog = false }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = TvSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, TvCardBorder),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth()
                ) {
                    Text(
                        text = "Playback Speed",
                        color = TvText,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
                    speeds.forEach { speed ->
                        val isSelected = currentSpeed == speed
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) TvElevated else Color.Transparent)
                                .clickable {
                                    currentSpeed = speed
                                    exoPlayer.playbackParameters = PlaybackParameters(speed)
                                    onSpeedChanged(speed)
                                    showSpeedDialog = false
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (speed == 1.0f) "1.0x (Normal)" else "${speed}x",
                                color = if (isSelected) TvAccent else TvText,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(TvAccent)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerViewComponent(
    exoPlayer: ExoPlayer,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = exoPlayer
                useController = false
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                keepScreenOn = true
            }
        },
        modifier = modifier
    )
}

@Composable
private fun PlayerControlsOverlay(
    channel: TvChannel,
    isPlaying: Boolean,
    isBuffering: Boolean,
    errorMessage: String?,
    areControlsVisible: Boolean,
    currentPosition: Long,
    totalDuration: Long,
    isLiveStream: Boolean,
    isMuted: Boolean,
    currentSpeed: Float,
    isFullscreen: Boolean,
    onTogglePlayPause: () -> Unit,
    onRewind10s: () -> Unit,
    onForward10s: () -> Unit,
    onToggleMute: () -> Unit,
    onOpenSpeedDialog: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onRetry: () -> Unit,
    onPlayNext: () -> Unit,
    onPlayPrevious: () -> Unit,
    onBack: () -> Unit,
    onTapScreen: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onTapScreen() }
    ) {
        // Buffering Indicator
        if (isBuffering && errorMessage == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x80050608)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        color = TvAccent,
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Loading stream...",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Clean Error State
        if (errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xF0050608))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = TvAccent,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Stream Offline",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "The live broadcast is temporarily unreachable.",
                        color = TvTextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(TvAccent)
                                .clickable { onRetry() }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(text = "Retry", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(TvElevated)
                                .border(1.dp, TvCardBorder, RoundedCornerShape(8.dp))
                                .clickable { onPlayNext() }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(text = "Next Channel", color = TvText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Animated Overlays
        AnimatedVisibility(
            visible = areControlsVisible && errorMessage == null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(TvPlayerOverlay)
            ) {
                // Top Overlay: Back button + Channel Title + Fullscreen Exit
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xCC000000), Color.Transparent)
                            )
                        )
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x55111319))
                                .testTag("player_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = channel.name,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    LiveBadge()
                }

                // Center Controls: Prev, Rewind 10s, Play/Pause, Forward 10s, Next
                Row(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onPlayPrevious,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    IconButton(
                        onClick = onRewind10s,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastRewind,
                            contentDescription = "Rewind",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(TvAccent)
                            .clickable { onTogglePlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    IconButton(
                        onClick = onForward10s,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Forward",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = onPlayNext,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Bottom Overlay: Live tag, Volume, Speed, Fullscreen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xDD000000))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(TvAccent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LIVE",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Mute button
                        IconButton(
                            onClick = onToggleMute,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeMute else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = if (isMuted) "Unmute" else "Mute",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Fullscreen Toggle
                        IconButton(
                            onClick = onToggleFullscreen,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                contentDescription = "Fullscreen",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionPillButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    iconTint: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0x331E2235))
            .border(1.dp, TvCardBorder, RoundedCornerShape(22.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                color = TvText,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

// Luxury YouTube-style Broadcast Channel Feed Item
@Composable
private fun YouTubeChannelFeedItem(
    channel: TvChannel,
    isCurrent: Boolean,
    onClick: () -> Unit
) {
    val cardBackground = if (isCurrent) {
        Brush.horizontalGradient(
            colors = listOf(
                Color(0x2E00E5FF),
                TvElevated,
                TvSurface
            )
        )
    } else {
        Brush.horizontalGradient(
            colors = listOf(TvSurface, TvSurface)
        )
    }

    val cardBorder = if (isCurrent) TvAccent else TvCardBorder

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(cardBackground)
            .border(if (isCurrent) 1.5.dp else 1.dp, cardBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 16:9 Broadcast Thumbnail with Live Badge
            Box(
                modifier = Modifier
                    .size(width = 112.dp, height = 68.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F111D))
                    .border(1.dp, TvCardBorder, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                ChannelAvatar(
                    channel = channel,
                    size = 52.dp,
                    shape = RoundedCornerShape(10.dp)
                )

                // Top-Left LIVE Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                ) {
                    LiveBadge()
                }

                // Bottom-Right HD Pill
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xD9000000))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "1080p",
                        color = Color(0xFF00E5FF),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Channel Details Column
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = channel.name,
                        color = TvText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (isCurrent) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(TvAccent)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "PLAYING",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = channel.currentProgram,
                    color = TvTextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(TvElevated)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = channel.category,
                            color = TvSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = channel.language,
                        color = TvTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
